#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Q1(a): Struct Definition and Data Storage
struct Student {
    int ID;
    string name;
    float grade;
};

Student students[100]; // Array to hold up to 100 students
int studentCount = 0;   // Counter for tracking number of students

// Q2(a): Add Student Function
void addStudent() {
    if (studentCount >= 100) {
        cout << "Student limit reached!\n";
        return;
    }

    Student s;
    cout << "Enter Student ID: ";
    cin >> s.ID;
    cin.ignore(); // Clear newline from buffer
    cout << "Enter Student Name: ";
    getline(cin, s.name);
    cout << "Enter Student Grade (0 - 100): ";
    cin >> s.grade;

    // Input validation
    if (s.grade < 0 || s.grade > 100) {
        cout << "Invalid grade. Must be between 0 and 100.\n";
        return;
    }

    students[studentCount++] = s;
    cout << "Student added successfully!\n";
}

// Q3(a): Display Students Function
void displayStudents() {
    if (studentCount == 0) {
        cout << "No student data available.\n";
        return;
    }

    cout << "ID\tName\t\tGrade\n";
    cout << "----------------------------\n";
    for (int i = 0; i < studentCount; i++) {
        cout << students[i].ID << "\t" << students[i].name << "\t\t" << students[i].grade << endl;
    }
}

// Q4(a): Search Student by ID
void searchStudent() {
    int id;
    cout << "Enter Student ID to search: ";
    cin >> id;

    bool found = false;
    for (int i = 0; i < studentCount; i++) {
        if (students[i].ID == id) { // Q4(b): '==' is comparison operator
            cout << "Student Found:\n";
            cout << "ID: " << students[i].ID << endl;
            cout << "Name: " << students[i].name << endl;
            cout << "Grade: " << students[i].grade << endl;
            found = true;
            break;
        }
    }

    if (!found) {
        cout << "Student not found.\n";
    }
}

// Q5(a): Calculate Average Grade
void calculateAverage() {
    if (studentCount == 0) { // Q5(b): Prevent division by zero
        cout << "No students to calculate average.\n";
        return;
    }

    float total = 0;
    for (int i = 0; i < studentCount; i++) {
        total += students[i].grade;
    }
    float average = total / studentCount;
    cout << "Average grade of all students: " << average << endl;
}

// Q6(a): Save Student Data to File
void saveToFile() {
    ofstream file("students.txt"); // Q6(b): ofstream is for writing
    for (int i = 0; i < studentCount; i++) {
        file << students[i].ID << "," << students[i].name << "," << students[i].grade << endl;
    }
    file.close();
    cout << "Data saved to file.\n";
}

// Q6(a): Load Student Data from File

void loadFromFile() {
    ifstream file("students.txt"); // Open the file for reading

    if (!file) {
        cout << "No saved file found. Starting fresh.\n";
        return; // Exit if file doesn't exist
    }

    string line;
    studentCount = 0; // Reset student count before loading

    // Read the file line by line
    while (getline(file, line)) {
        if (line.empty()) continue; // Skip empty lines

        size_t pos1 = line.find(','); // First comma (separates ID)
        size_t pos2 = line.rfind(','); // Last comma (separates grade)

        // Error check: ensure commas are found and in correct order
        if (pos1 == string::npos || pos2 == string::npos || pos1 == pos2) {
            cout << "Skipping invalid line: " << line << "\n";
            continue;
        }

        Student s;
        try {
            s.ID = stoi(line.substr(0, pos1)); // Convert ID to integer
            s.name = line.substr(pos1 + 1, pos2 - pos1 - 1); // Extract name
            s.grade = stof(line.substr(pos2 + 1)); // Convert grade to float
        } catch (...) {
            cout << "Error parsing line: " << line << "\n";
            continue;
        }

        students[studentCount++] = s; // Store the student and increment counter
    }

    file.close(); // Always close the file
    cout << "? Loaded " << studentCount << " student(s) from file.\n";
}

// Q7: Main Menu System with do-while loop
int main() {
    loadFromFile(); // Load existing data at start
    int choice;

    do {
        cout << "\n--- MENU ---\n";
        cout << "1. Add Student\n";
        cout << "2. Display Students\n";
        cout << "3. Search Student\n";
        cout << "4. Calculate Average\n";
        cout << "5. Save and Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: addStudent(); break;
            case 2: displayStudents(); break;
            case 3: searchStudent(); break;
            case 4: calculateAverage(); break;
            case 5: saveToFile(); cout << "Exiting...\n"; break;
            default: cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 5);

    return 0;
}
